# AI usage

## Tools I used, and for which functions

I used ChatGPT to explain the assignment specification and help draft the implementations of `rawaj/audit.py` (`audit`) and `rawaj/metrics.py` (`confusion_at`, `precision_recall_at`, `precision_at_k`, `expected_cost`, `best_threshold`, and `threshold_for_precision`). I used the provided README and Week 2 slides as the requirements source. I ran the provided tests with Python, pandas, NumPy, scikit-learn, and pytest, and inspected the sample-data audit output.

## One place where the AI was wrong, incomplete, or not what the spec said

The Week 2 slide shows a threshold-search snippet using ascending `np.unique(scores)` with `np.argmin`. Following that pattern literally selects the lowest threshold when two candidates have the same expected cost. The README explicitly requires the highest threshold on a cost tie. I noticed the mismatch by checking the README clarification and implemented an explicit tie-break that prefers the higher threshold. The README is the task's detailed grading specification, so its rule takes precedence over the abbreviated slide snippet.

## The function I wrote without AI, and why

I have not yet written a complete function in this submission without AI assistance: both implementation files were drafted with ChatGPT. I do not want to claim otherwise. To complete this part of the reflection honestly, I should independently rewrite one small function (for example, `confusion_at`) from the specification, run the tests, and then replace this paragraph with the function name and what I learned from implementing it myself.
